# rag_engine.py
import os
from pathlib import Path
import pandas as pd
import chromadb
from chromadb.utils.embedding_functions import OpenAIEmbeddingFunction
from openai import OpenAI
from dotenv import load_dotenv


HERE = Path(__file__).parent
load_dotenv(dotenv_path=HERE / ".env")


OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")

if not OPENAI_API_KEY:
    raise RuntimeError(
        "OPENAI_API_KEY not found. Create a .env file next to rag_engine.py with:\n"
        "OPENAI_API_KEY=sk-...\n"
        "Or set the OPENAI_API_KEY environment variable before running Streamlit."
    )


client_ai = OpenAI(api_key=OPENAI_API_KEY)


chroma_client = chromadb.PersistentClient(path=str(HERE / "vector_db"))


embedding_fn = OpenAIEmbeddingFunction(api_key=OPENAI_API_KEY, model_name="text-embedding-3-small")


def _row_to_text(row: pd.Series) -> str:
    
    return " | ".join([f"{k}: {v}" for k, v in row.items()])


def build_rag_index(df: pd.DataFrame, collection_name: str = "dataset_collection"):
    
    try:
        chroma_client.delete_collection(collection_name)
    except Exception:
        pass

    
    collection = chroma_client.create_collection(
        name=collection_name,
        embedding_function=embedding_fn
    )

    docs = []
    metadatas = []
    ids = []
    for i, row in df.iterrows():
        txt = _row_to_text(row)
        docs.append(txt)
        metadatas.append({"row_index": int(i)})
        ids.append(str(i))

   
    collection.add(ids=ids, documents=docs, metadatas=metadatas)

    
    return {"collection": collection_name, "count": len(docs)}


def rag_query(question: str, collection_name: str = "dataset_collection") -> str:
    
    collection = chroma_client.get_collection(name=collection_name)

   
    results = collection.query(query_texts=[question], n_results=5)

    
    docs_for_query = results["documents"][0] if results and "documents" in results else []
    context_text = "\n---\n".join(docs_for_query)

    prompt = (
        
        f"Context:\n{context_text}\n\nQuestion: {question}"
    )

   
    resp = client_ai.chat.completions.create(
        model="gpt-4o-mini",
        messages=[
            {"role": "system", "content": "You are a helpful data analyst. Answer only from the dataset context."},
            {"role": "user", "content": prompt},
        ],
        max_tokens=512,
        temperature=0.0,
    )

    
    try:
        return resp.choices[0].message.content
    except Exception:
        
        return str(resp)
