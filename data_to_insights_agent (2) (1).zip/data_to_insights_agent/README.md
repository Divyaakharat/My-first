Data-to-Insights RAG Agent
Run: streamlit run app.py
Set OPENAI_API_KEY env var.
