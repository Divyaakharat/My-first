import os
from openai import OpenAI
import pandas as pd
from dotenv import load_dotenv

load_dotenv()

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

def df_to_prompt(df: pd.DataFrame, max_rows=10):
    sample = df.head(max_rows).copy()
    sample.fillna('', inplace=True)
    header = '\t'.join(list(sample.columns))
    rows = '\n'.join(['\t'.join(map(str, r)) for r in sample.values.tolist()])
    return f"Columns:\n{header}\n\nSample rows:\n{rows}"

def generate_insights(df: pd.DataFrame) -> str:
    prompt = (
        "You are a data analyst assistant. Provide:\n"
        "1) Top insights\n2) Data quality issues\n3) Next steps.\n\n"
    )
    prompt += df_to_prompt(df, max_rows=8)

    response = client.responses.create(
        model="gpt-4o-mini",
        input=prompt
    )

    return response.output_text
