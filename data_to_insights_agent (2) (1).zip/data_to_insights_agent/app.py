import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
from data_processor import summarize_dataframe, plot_columns
from insights_agent import generate_insights
from rag_engine import build_rag_index, rag_query

st.set_page_config(page_title='Data-to-Insights RAG Agent', layout='wide')
st.title('Data-to-Insights — RAG Agent')

with st.sidebar:
    st.header('Upload Dataset')
    uploaded_file = st.file_uploader('Upload CSV or Excel', type=['csv', 'xlsx'])
    st.markdown('---')
    st.header('RAG Q&A')
    question = st.text_input('Ask a question about the dataset')
    run_rag = st.button('Ask')
    st.markdown('---')
    if st.button('Generate AI Insights'):
        st.session_state['insights'] = True

if uploaded_file is None:
    st.info('Upload a CSV or Excel file to start.')
    st.stop()

if uploaded_file.name.endswith('.csv'):
    df = pd.read_csv(uploaded_file)
else:
    df = pd.read_excel(uploaded_file)

st.subheader('Preview')
st.dataframe(df.head())

st.subheader('Summary')
summary = summarize_dataframe(df)
for k, v in summary.items():
    st.markdown(f'**{k}**')
    st.write(v)

st.subheader('Visualizations')
plot_type = st.selectbox('Chart type', ['bar', 'line', 'histogram', 'box'])
col1, col2 = st.columns(2)
with col1:
    x_col = st.selectbox('X column', df.columns)
with col2:
    y_col = st.selectbox('Y column (numeric)', [c for c in df.columns if pd.api.types.is_numeric_dtype(df[c])])

if st.button('Plot'):
    plot_columns(df, x_col, y_col, plot_type)  # 👈 st.pyplot(fig) REMOVE KELAY

st.subheader('AI Insights')
if st.button('Generate automated insights') or st.session_state.get('insights'):
    with st.spinner('Generating insights...'):
        insights_text = generate_insights(df)
    st.write(insights_text)

if st.button('Build RAG index'):
    with st.spinner('Building RAG index...'):
        idx_meta = build_rag_index(df)
    st.success('RAG index built.')

if run_rag and question.strip():
    with st.spinner('Running RAG...'):
        answer = rag_query(question)
    st.subheader('Answer')
    st.write(answer)
