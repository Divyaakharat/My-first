import pandas as pd
import matplotlib.pyplot as plt
from io import BytesIO
import streamlit as st

def summarize_dataframe(df: pd.DataFrame) -> dict:
    return {
        "Shape": df.shape,
        "Columns": list(df.columns),
        "Dtypes": df.dtypes.astype(str).to_dict(),
        "Missing Values": df.isnull().sum().to_dict(),
        "Numeric Summary": df.describe().T.to_dict(),
    }


def plot_columns(df, x_col, y_col, plot_type='bar'):
    fig, ax = plt.subplots()

    if plot_type == 'bar':
        df.groupby(x_col)[y_col].mean().plot(kind='bar', ax=ax)
    elif plot_type == 'line':
        df.sort_values(x_col).plot(x=x_col, y=y_col, kind='line', ax=ax)
    elif plot_type == 'histogram':
        df[y_col].plot(kind='hist', ax=ax)
    elif plot_type == 'box':
        df.boxplot(column=[y_col], by=x_col, ax=ax)

    ax.set_title(f"{plot_type.title()} of {y_col} by {x_col}")

    buf = BytesIO()
    fig.savefig(buf, format="png", dpi=300)
    buf.seek(0)

    # show only here
    st.pyplot(fig)

    st.download_button(
        label="📥 Download Chart",
        data=buf,
        file_name=f"{plot_type}_{x_col}_{y_col}.png",
        mime="image/png"
    )

    return fig
